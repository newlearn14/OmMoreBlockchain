Submitting Date:  02/08/2024<br>
Everything is Followed as Per Steps: Yes<br>
Assignment Level: Easy<br>
Code Quality Maintained: Yes<br>
Notes: The code includes detailed comments and documentation as per the assignment requirements.
